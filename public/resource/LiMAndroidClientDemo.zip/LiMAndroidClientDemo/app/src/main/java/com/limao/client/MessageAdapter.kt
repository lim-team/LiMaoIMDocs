package com.limao.client

import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.xinbida.limaoim.message.type.LiMSendMsgResult

class MessageAdapter : BaseQuickAdapter<UIMessageEntity, BaseViewHolder>(R.layout.item_msg_layout) {
    override fun convert(holder: BaseViewHolder, item: UIMessageEntity) {
        holder.setText(
            R.id.contentTv,
            item.liMMsg.baseContentMsgModel.getDisplayContent()
        )
        if (item.liMMsg.status == LiMSendMsgResult.send_loading) {
            holder.setText(R.id.statusTv, "发送中")
        } else if (item.liMMsg.status > LiMSendMsgResult.send_success) {
            holder.setText(R.id.statusTv, "发送失败")
        } else {
            holder.setText(R.id.statusTv, "")
        }
        holder.setGone(
            R.id.statusTv,
            item.liMMsg.status == LiMSendMsgResult.send_success
        )

    }
}