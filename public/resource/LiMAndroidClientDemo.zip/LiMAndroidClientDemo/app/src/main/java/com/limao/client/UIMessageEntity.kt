package com.limao.client

import com.xinbida.limaoim.entity.LiMMsg

class UIMessageEntity(val liMMsg: LiMMsg) {
}