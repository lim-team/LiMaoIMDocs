package com.limao.client

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.xinbida.limaoim.LiMaoIM
import com.xinbida.limaoim.entity.LiMMsg
import com.xinbida.limaoim.interfaces.IGetSocketIpAndPortListener
import com.xinbida.limaoim.message.type.LiMChannelType
import com.xinbida.limaoim.message.type.LiMConnectReason
import com.xinbida.limaoim.message.type.LiMConnectStatus
import com.xinbida.limaoim.msgmodel.LiMTextContent

class MainActivity : AppCompatActivity() {
    private lateinit var statusTv: TextView
    private lateinit var contentET: EditText
    private lateinit var toUidET: EditText
    private lateinit var uidET: EditText
    private lateinit var urlET: EditText
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MessageAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        init()
        listener()
    }

    private fun init() {
        urlET = findViewById(R.id.urlET)
        uidET = findViewById(R.id.uidET)
        toUidET = findViewById(R.id.toUidET)
        contentET = findViewById(R.id.contentET)
        statusTv = findViewById(R.id.statusTv)
        recyclerView = findViewById(R.id.recycleView)
        adapter = MessageAdapter()
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
    }

    @SuppressLint("SetTextI18n")
    private fun listener() {
        LiMaoIM.getInstance().liMConnectionManager.addOnConnectionStatusListener(
            "main_act"
        ) { status, reason ->
            var text = ""
            when (status) {
                LiMConnectStatus.syncMsg -> {
                    text = "正在同步消息"
                }
                LiMConnectStatus.success -> {
                    text = "成功"
                }
                LiMConnectStatus.connecting -> {
                    text = "连接中"
                }
                LiMConnectStatus.noNetwork -> {
                    text = "网络错误"
                }
                LiMConnectStatus.kicked -> {
                    text = if (reason == LiMConnectReason.ReasonConnectKick) {
                        "被踢"
                    } else {
                        "认证失败"
                    }
                }
            }
            statusTv.text = "连接状态：$text"
        }

        findViewById<View>(R.id.connectBtn).setOnClickListener {
            val uid: String = uidET.text.toString()
            val url: String = urlET.text.toString()

            val token = uid + "123"
            if (!TextUtils.isEmpty(uid) && !TextUtils.isEmpty(url)) {
                // 初始化im
                LiMaoIM.getInstance().initIM(this@MainActivity, uid, token)
                // 连接
                LiMaoIM.getInstance().liMConnectionManager.connection()
            } else {
                Toast.makeText(this, "uid和请求地址不能为空", Toast.LENGTH_LONG).show()
            }

        }
        findViewById<View>(R.id.sendBtn).setOnClickListener {
            val content: String = contentET.text.toString()
            val uid: String = toUidET.text.toString()
            if (!TextUtils.isEmpty(content) && !TextUtils.isEmpty(uid)) {
                // 发送消息
                LiMaoIM.getInstance().liMMsgManager
                    .sendMessage(LiMTextContent(content), uid, LiMChannelType.PERSONAL)
            }
        }
        // 新消息监听
        LiMaoIM.getInstance().liMMsgManager.addOnNewMsgListener(
            "new_msg"
        ) { liMMsgList: List<LiMMsg?> ->
            for (liMMsg in liMMsgList) {
                adapter.addData(UIMessageEntity(liMMsg!!))
            }
        }
        // 监听发送消息入库返回
        LiMaoIM.getInstance().liMMsgManager.addOnSendMsgCallback(
            "insert_msg"
        ) { liMMsg: LiMMsg? -> adapter.addData(UIMessageEntity(liMMsg!!)) }
        // 发送消息回执
        LiMaoIM.getInstance().liMMsgManager.addOnSendMsgAckListener(
            "ack_key"
        ) { liMMsg ->
            var i = 0
            val size: Int = adapter.data.size
            while (i < size) {
                if (adapter.data[i].liMMsg.clientSeq == liMMsg.clientSeq) {
                    adapter.data[i].liMMsg.status = liMMsg.status
                    adapter.notifyItemChanged(i)
                    break
                }
                i++
            }
        }
        LiMaoIM.getInstance().liMConnectionManager.addOnGetIpAndPortListener { andPortListener: IGetSocketIpAndPortListener ->
            Thread {
                HttpsUtils.getIP(
                    urlET.text.toString(),
                    uidET.text.toString()
                ) { ip, port -> andPortListener.onGetSocketIpAndPort(ip, port!!.toInt()) }
            }.start()
        }
    }

    override fun finish() {
        super.finish()
        // 断开连接
        LiMaoIM.getInstance().liMConnectionManager.disconnect(true)
        // 取消监听
        LiMaoIM.getInstance().liMMsgManager.removeNewMsgListener("new_msg")
        LiMaoIM.getInstance().liMMsgManager.removeSendMsgCallBack("insert_msg")
        LiMaoIM.getInstance().liMMsgManager.removeSendMsgAckListener("ack_key")
        LiMaoIM.getInstance().liMConnectionManager.removeOnConnectionStatusListener("main_act")
    }

}